#!/bin/zsh
export PATH="$PATH:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export HOME="/Users/kjr"
cd "/Users/kjr"
rm -rf ~/sam 2>/dev/null; mkdir -p ~/sam && cd ~/sam && \
git clone --depth 1 https://github.com/s-macke/SAM.git . && \
sed -i '' 's/buffer = malloc(22050\*20);/buffer = malloc(22050*600);/g' src/sam.c && \
cat > Makefile << 'EOL'
CC = gcc
CFLAGS = -Wall -O0 -g
OBJS = reciter.o sam.o render.o main.o debug.o
sam: $(OBJS)
	$(CC) -o sam $(OBJS)
%.o: src/%.c
	$(CC) $(CFLAGS) -c $< -o $@
clean:
	rm -f *.o sam
EOL
make clean && make && \
cat > ~/sam/saysam << 'EOL'
#!/bin/bash
cd ~/sam
SPEED=72
PITCH=64
THROUT=128
MOUTH=128
SAVE_PATH=""
show_help() {
    echo "SAM Speech Synthesizer Wrapper"
    echo "Usage: saysam [preset/flags] \"Your text here\""
    echo ""
    echo "Presets:"
    echo "  -elf          Elf voice settings"
    echo "  -robot        Robot voice settings"
    echo "  -stuffy       Stuffy nose settings"
    echo "  -old-lady     Old lady voice settings"
    echo "  -et           E.T. voice settings"
    echo "  -sam          Default SAM settings"
    echo ""
    echo "Manual Flags:"
    echo "  -speed X      Set speed (integer)"
    echo "  -pitch X      Set pitch (integer)"
    echo "  -throat X     Set throat (integer)"
    echo "  -mouth X      Set mouth (integer)"
    echo ""
    echo "Utility Flags:"
    echo "  -save \"path\"  Saves the generated .wav to specified directory instead of playing it"
    echo "  -help         Show this help menu"
    exit 0
}
while [[ $# -gt 0 ]]; do
    case "$1" in
        -help) show_help ;;
        -elf)      SPEED=72;  PITCH=64; THROUT=110; MOUTH=160; shift ;;
        -robot)    SPEED=92;  PITCH=60; THROUT=190; MOUTH=190; shift ;;
        -stuffy)   SPEED=82;  PITCH=72; THROUT=110; MOUTH=105; shift ;;
        -old-lady) SPEED=82;  PITCH=32; THROUT=145; MOUTH=145; shift ;;
        -et)       SPEED=100; PITCH=64; THROUT=150; MOUTH=200; shift ;;
        -sam)      SPEED=72;  PITCH=64; THROUT=128; MOUTH=128; shift ;;
        -speed)    SPEED="$2"; shift 2 ;;
        -pitch)    PITCH="$2"; shift 2 ;;
        -throat)   THROUT="$2"; shift 2 ;;
        -mouth)    MOUTH="$2"; shift 2 ;;
        -save)     SAVE_PATH="$2"; shift 2 ;;
        -*)        echo "Unknown option: $1"; show_help ;;
        *)         break ;;
    esac
done
TEXT="$*"
[ -z "$TEXT" ] && exit 0
if [[ "$SAVE_PATH" == "~"* ]]; then
    SAVE_PATH="${HOME}${SAVE_PATH#\~}"
fi
TEXT=$(echo "$TEXT" | sed 's/,/, /g' | sed 's/\./\. /g' | sed 's/!/! /g' | sed 's/?/? /g')
TEXT=$(echo "$TEXT" | tr -dc '[:alnum:].,!? \n\r')
SAM_ARGS=(-speed "$SPEED" -pitch "$PITCH" -throat "$THROUT" -mouth "$MOUTH")
rm -f /tmp/sam_chunk_*.wav /tmp/sam_list.txt 2>/dev/null
if [ -n "$SAVE_PATH" ]; then
    mkdir -p "$SAVE_PATH"
    SAFE_NAME=$(echo "$TEXT" | tr -d '.,;:!?' | tr -dc '[:alnum:]\n\r ' | tr ' ' '_' | cut -c1-30)
    [ -z "$SAFE_NAME" ] && SAFE_NAME="sam_speech"
    FINAL_OUTPUT="$SAVE_PATH/${SAFE_NAME}.wav"
    rm -f "$FINAL_OUTPUT"
fi
CHUNK_COUNT=0
echo "$TEXT" | tr '[:cntrl:]' ' ' | xargs -n 8 | while read -r chunk; do
    [ -z "$chunk" ] && continue
    CHUNK_FILE=$(printf "/tmp/sam_chunk_%04d.wav" "$CHUNK_COUNT")
    ./sam "${SAM_ARGS[@]}" -wav "$CHUNK_FILE" "$chunk" >/dev/null 2>&1
    if [ -f "$CHUNK_FILE" ]; then
        echo "file '$CHUNK_FILE'" >> /tmp/sam_list.txt
        ((CHUNK_COUNT++))
    fi
done
if [ ! -f /tmp/sam_list.txt ]; then exit 0; fi
if [ -n "$SAVE_PATH" ]; then
    while read -r line; do
        FILE_PATH=$(echo "$line" | cut -d"'" -f2)
        cat "$FILE_PATH" >> "$FINAL_OUTPUT"
    done < /tmp/sam_list.txt
else
    while read -r line; do
        FILE_PATH=$(echo "$line" | cut -d"'" -f2)
        afplay "$FILE_PATH" 2>/dev/null
    done < /tmp/sam_list.txt
fi
rm -f /tmp/sam_chunk_*.wav /tmp/sam_list.txt 2>/dev/null
EOL
chmod +x ~/sam/saysam && mkdir -p ~/bin && ln -sf ~/sam/saysam ~/bin/saysam && \
rm -rf src Makefile README.md LICENSE *.o 2>/dev/null && \
cd && \
echo Done